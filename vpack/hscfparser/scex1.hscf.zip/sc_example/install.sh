#!/usr/bin/env bash
apk add python3;
echo "RFL";