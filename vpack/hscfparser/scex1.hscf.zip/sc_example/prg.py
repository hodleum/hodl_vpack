# hdn import

# @hdn.task(info="Main Task", main=True)


def main_t(args):
    print("Hello, world!", args)
